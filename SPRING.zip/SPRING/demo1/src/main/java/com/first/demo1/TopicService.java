package com.first.demo1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
public class TopicService {
	
	public List<Topic> getAllTopics()
	{
		return topic;
	//return Topic;
	}
	
	public List<Topic> topic=new ArrayList<Topic> (Arrays.asList(new Topic("1","Let us C","Best Book to learn c" ),
			new Topic("2","java","Quoick guide"),
			new Topic("3"," C","Spring fundamentals"),
			new Topic("4","python","Best"),
			new Topic("5","ruby","Best Book ever")
			));
	
	
	public Topic getTopic(String id) {
		return topic.stream().filter(t->t.getId().equals(id)).findFirst().get();
		
	}
	
	public void addTopic(Topic topic) {
		
		this.topic.add(topic);
	}

	public void deleteTopic(String id) {
		topic.removeIf(t->t.getId().equals(id));
		
	}
	
	public void updateTopic(Topic topic2) {
		Topic temp= topic.stream().filter(t->t.getId().equals(topic2.getId())).findFirst().get();
		int i=topic.indexOf(temp);
		topic.set(i, topic2);
		
	}
	 

}
